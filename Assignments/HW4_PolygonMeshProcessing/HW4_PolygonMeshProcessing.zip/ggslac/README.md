# ggslac
Geometry/Graphics Library for Small Liberal Arts Colleges
