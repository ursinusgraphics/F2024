/**
 * Check if two faces are oriented with respect to each other
 * @param {MeshEdge} edge Shared Edge
 * @param {MeshFace} face1 First face
 * @param {MeshFace} face2 Second Face
 * @returns 
 */
function facesOriented(edge, face1, face2) {
    let vs1 = face1.getVertices();
    let vs2 = face2.getVertices();
    // Vertices of edge should be in opposite order
    // between the two faces
    let orient1 = false;
    let orient2 = false;
    for (let k = 0; k < vs1.length; k++) {
        if (edge.v1 == vs1[k] && edge.v2 == vs1[(k+1)%vs1.length]) {
            orient1 = true;
        }
        else if (edge.v2 == vs1[k] && edge.v1 == vs1[(k+1)%vs1.length]) {
            orient2 = true;
        }
    }
    for (let k = 0; k < vs2.length; k++) {
        if (edge.v1 == vs2[k] && edge.v2 == vs2[(k+1)%vs2.length]) {
            orient1 = true;
        }
        else if (edge.v2 == vs2[k] && edge.v1 == vs2[(k+1)%vs2.length]) {
            orient2 = true;
        }
    }
    return orient1 && orient2;
}

/*
* Stuff you have access to:
face.edges // A list of edges on each face
edge.faceAcross(face); // Get the face on the other side of an edge
face.flipOrientation(); // Flip the orientation of a face
*/

function consistentlyOrientFaces(mesh) {
    // Initialize variables to say whether a face has been oriented yet
    for (let i = 0; i < mesh.faces.length; i++) {
        mesh.faces[i].oriented = false;
    }
    // TODO: Fill this in
}


function consistentlyOrientFacesEntry() {
    consistentlyOrientFaces(this);
    this.needsDisplayUpdate = true;
}
