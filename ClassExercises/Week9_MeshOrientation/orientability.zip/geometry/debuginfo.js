        let s = "";
        for (let i = 0; i < this.faces.length; i++) {
            s += i + ": ";
            let f = this.faces[i];
            for (let j = 0; j < f.edges.length; j++) {
                let e = f.edges[j];
                s += e.v1.ID + "_" + e.v2.ID + ", ";
            }
            let verts = f.getVertices();
            s += "("
            for (let j = 0; j < verts.length; j++) {
                s += verts[j].ID + ", "
            }
            s += ")\n";
        }
        console.log(s);
